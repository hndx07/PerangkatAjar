# Perangkat Ajar Terpadu · ATP → Materi → RPP

Gabungan dua aplikasi (**RPP-main** dan **Prompting-Materi-Ajar**) menjadi satu aplikasi dengan alur kerja berurutan, satu penyimpanan data, dan satu deploy Cloudflare Worker.

## Alur kerja

| Langkah | Halaman | Yang dilakukan |
|---|---|---|
| **1. ATP** | Unggah Excel CP / RPP Terintegrasi (atau pilih contoh) → tinjau & cetak ATP | Setiap baris menjadi satu **unit** (1 materi = 1 RPP) |
| **2. Materi** | Pilih unit → form generator prompt **terisi otomatis dari ATP** → salin prompt ke AI → tempel tautan hasil slide | Tautan masuk ke **Lampiran 1** RPP unit tersebut |
| **3. RPP** | Tinjau, sunting (Editor RPP), dan cetak RPP Deep Learning F4 | Lampiran memuat materi dari Langkah 2 |

Isian otomatis dari ATP: mata pelajaran, topik (judul unit), kelas/fase/semester, sekolah & jurusan, durasi (JP), CP, TP, alur ATP, asesmen formatif/sumatif, pengetahuan awal, pendekatan, nama guru.

**Pengaturan bersama** (cukup diisi sekali, berlaku di semua unit): tema visual, palet, logo & background sekolah, bahasa, perangkat kelas, dan seluruh pengaturan kuis (Web3Forms/Apps Script, timer, anti-curang). Isian lain disimpan **per unit**.

## Struktur proyek

```
src/
  App.tsx                 shell: Stepper + 3 langkah + modal bersama
  workflow/               ← lapisan penghubung (baru)
    useWorkspace.ts       satu sumber state (logika RPP asli + materi + langkah)
    bridge.ts             ATP → form materi, tautan → Lampiran RPP (fungsi murni)
    Stepper.tsx · UnitPicker.tsx · LinkPanel.tsx · steps/*
  rpp/                    modul RPP-main (komponen, generator, parser Excel, cetak)
  materi/                 modul Prompting-Materi-Ajar (form, preset, generator prompt)
_worker.ts                Worker produksi: API AI + melayani aset statis
lib/ai-provider.ts        Groq (utama) → Gemini (cadangan)
server.ts                 server pengembangan lokal (Express + Vite)
wrangler.toml             konfigurasi Cloudflare
```

## Menjalankan di komputer

```bash
npm install
cp .env.example .env        # isi GROQ_API_KEY dan/atau GEMINI_API_KEY
npm run dev                 # http://localhost:3000 (UI + API AI)
```

Tanpa API key, seluruh alur ATP → Materi → RPP tetap berjalan; hanya tombol **Auto-Isi Topik Baru dengan AI** yang membutuhkan key.

## Deploy ke Cloudflare Workers

```bash
npm install
npx wrangler login
npx wrangler secret put GROQ_API_KEY       # utama (disarankan)
npx wrangler secret put GEMINI_API_KEY     # cadangan (opsional)
npm run deploy                             # build otomatis, lalu deploy
```

Worker bernama `perangkat-ajar-terpadu` (ubah di `wrangler.toml`). Setelah deploy, cek `https://<nama>.workers.dev/api/ai-status`.

**Lewat Git (Workers Builds):** Build command `npm run build`, Deploy command `npx wrangler deploy`. Secret diisi di *Settings → Variables and Secrets*.

## Catatan penting

- **Data tersimpan di browser** (localStorage) dan tetap ada setelah refresh. Data tidak berpindah antar perangkat/peramban, jadi gunakan **Ekspor Excel** untuk cadangan. Tombol **Reset Data** menghapus semuanya.
- **Mengganti data ATP** (unggah Excel baru) mempertahankan isian materi unit yang judulnya sama; unit dengan judul baru memakai isian otomatis dari ATP.
- **Mengedit tabel CP** akan menyusun ulang seluruh dokumen dari tabel (perilaku RPP-main asli), sehingga tautan materi yang sudah dihubungkan pada mode CP ikut terhapus. Pada mode RPP Terintegrasi tautan ikut tersimpan di tabel.
- **Hasil slide** perlu diterbitkan sendiri (mis. Blogger, GitHub Pages, Cloudflare Pages); aplikasi menyimpan tautannya, bukan berkas HTML-nya.
- `GET /api/debug-key` (bawaan aplikasi Prompting) menampilkan nama variabel lingkungan dan panjang key, tanpa nilai key. Hapus rutenya di `_worker.ts` bila tidak dibutuhkan di produksi.

## Perubahan dari dua aplikasi asal

- Digabung: state RPP, penyimpanan otomatis, dan Worker API kini satu. Kunci penyimpanan `rpp-generator:v1:*` dipertahankan (ditambah `materi`), sehingga data RPP lama di domain yang sama tetap terbaca.
- Dihapus: `functions/` (duplikat Pages Functions dari `_worker.ts`), `public/index.html` (halaman placeholder yang bentrok dengan `index.html` Vite), `AiExecutionModal` (tidak dipakai di mana pun), dan dependensi tak terpakai `@google/genai` serta `motion`. `bun.lock` lama tidak disertakan; `npm install` membuat lockfile baru.
- Gaya cetak F4 landscape RPP-main tidak diubah.
